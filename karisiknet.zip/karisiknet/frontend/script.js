// ⭐ DEĞİŞMEDİ: Sayfa değiştirme
function showSection(id) {
    // Tüm bölümleri gizle
    ['home', 'info', 'about', 'aiktr'].forEach(s => {  // 'aiktr' EKLENDİ
        const el = document.getElementById(s);
        if(el) el.style.display = (s === id) ? 'block' : 'none';
    });
    
    // Aktif nav linkini güncelle (opsiyonel)
    document.querySelectorAll('nav a').forEach(link => {
        link.style.color = link.textContent.includes(getSectionName(id)) ? 'var(--primary)' : '';
    });
}

// Yardımcı fonksiyon
function getSectionName(id) {
    const names = {
        'home': 'Giriş',
        'info': 'Bilgi Arşivi',
        'about': 'Hakkımda',
        'aiktr': 'AİKTR'
    };
    return names[id] || '';
}

// ⭐ YENİ: Otomatik giriş fonksiyonu
async function autoLogin() {
    const savedUsername = localStorage.getItem('admin_username');
    const savedPassword = localStorage.getItem('admin_password');
    
    if (!savedUsername || !savedPassword) {
        showLoginForm();
        return;
    }
    
    try {
        const res = await fetch('/api/admin-login', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ 
                username: savedUsername, 
                password: savedPassword 
            })
        });
        
        if(res.ok) {
            // Giriş başarılı
            document.getElementById('login-area').style.display = 'none';
            document.getElementById('admin-panel').style.display = 'block';
            loadData();
            
            // Admin panel fonksiyonlarını başlat
            if (typeof window.onAdminLogin === 'function') {
                window.onAdminLogin();
            }
        } else {
            showLoginForm('Kayıtlı bilgilerinizle giriş başarısız');
        }
    } catch (err) {
        showLoginForm('Sunucu bağlantı hatası');
    }
}

// ⭐ YENİ: Manuel giriş formu göster
function showLoginForm(message = '') {
    const loginArea = document.getElementById('login-area');
    if (!loginArea) return;
    
    loginArea.innerHTML = `
        <h2>🔐 Yönetici Girişi</h2>
        ${message ? `<div style="color:red; margin-bottom:10px;">${message}</div>` : ''}
        <label for="admin-user">Kullanıcı Adı</label>
        <input type="text" id="admin-user" placeholder="admin">
        
        <label for="admin-pass" style="margin-top: 10px; display: block;">Şifre</label>
        <input type="password" id="admin-pass" placeholder="Şifreniz">
        
        <button onclick="performLogin()" style="width: 100%; background: var(--primary); color: white; margin-top: 20px;">
            Giriş Yap
        </button>
        
        <div style="margin-top: 15px; text-align: center;">
            <label>
                <input type="checkbox" id="remember-me" checked>
                Beni hatırla
            </label>
        </div>
    `;
}

// ⭐ YENİ: Manuel giriş yap
async function performLogin() {
    const username = document.getElementById('admin-user').value;
    const password = document.getElementById('admin-pass').value;
    const rememberMe = document.getElementById('remember-me')?.checked;

    const res = await fetch('/api/admin-login', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ username, password })
    });

    if(res.ok) {
        // Beni hatırla seçeneği
        if (rememberMe) {
            localStorage.setItem('admin_username', username);
            localStorage.setItem('admin_password', password);
        }
        
        document.getElementById('login-area').style.display = 'none';
        document.getElementById('admin-panel').style.display = 'block';
        loadData();
        
        if (typeof window.onAdminLogin === 'function') {
            window.onAdminLogin();
        }
    } else {
        alert("Giriş Başarısız! Kullanıcı adı veya şifre yanlış.");
    }
}

// ⭐ DEĞİŞMEDİ: Tüm verileri yükle
async function loadData() {
    // Ayarlar
    const sRes = await fetch('/api/settings');
    const settings = await sRes.json();
    settings.forEach(s => {
        if(s.key === 'about_text' && document.getElementById('about-display')) 
            document.getElementById('about-display').innerText = s.value;
        if(s.key === 'hero_text' && document.getElementById('hero-display')) 
            document.getElementById('hero-display').innerText = s.value;
        
        if(s.key === 'about_text' && document.getElementById('about_input')) 
            document.getElementById('about_input').value = s.value;
        if(s.key === 'hero_text' && document.getElementById('hero_input')) 
            document.getElementById('hero_input').value = s.value;
    });

    // Paylaşımlar
    const pRes = await fetch('/api/posts');
    const posts = await pRes.json();
    
    // Ana Sayfa Görünümü
    const allPosts = document.getElementById('all-posts');
    if(allPosts) {
        allPosts.innerHTML = posts.map(p => `
            <div class="card">
                <h3>${p.title}</h3>
                <p>${p.content}</p>
                ${p.image_url ? `<img src="${p.image_url}" style="width:100%; border-radius:10px;">` : ''}
            </div>
        `).join('');
    }

    // Admin Panelindeki Liste
    const manageList = document.getElementById('manage-posts-list');
    if(manageList) {
        manageList.innerHTML = posts.map(p => `
            <div class="card" style="display:flex; justify-content:space-between; align-items:center;">
                <span>${p.title}</span>
                <button onclick="deletePost(${p.id})" style="background:red; color:white; border:none; padding:5px 10px; cursor:pointer;">Sil</button>
            </div>
        `).join('');
    }
}

// ⭐ DEĞİŞMEDİ: Paylaşım silme
async function deletePost(id) {
    if(confirm('Bu paylaşımı silmek istediğine emin misin?')) {
        await fetch(`/api/posts/${id}`, { method: 'DELETE' });
        loadData();
    }
}

// ⭐ DEĞİŞMEDİ: Ayarları güncelle
async function updateSettings() {
    const hero_text = document.getElementById('hero_input').value;
    const about_text = document.getElementById('about_input').value;

    const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hero_text, about_text })
    });

    if (res.ok) {
        alert("Metinler başarıyla güncellendi!");
        loadData();
    } else {
        alert("Güncelleme sırasında bir hata oluştu.");
    }
}

// ⭐ YENİ: Şifre değiştirme fonksiyonu
async function changePassword() {
    const oldPass = document.getElementById('old-pass')?.value;
    const newPass = document.getElementById('new-pass')?.value;
    const newPassConfirm = document.getElementById('new-pass-confirm')?.value;
    
    if (!oldPass || !newPass || !newPassConfirm) {
        alert("Lütfen tüm alanları doldurun!");
        return;
    }
    
    if (newPass !== newPassConfirm) {
        alert("Yeni şifreler eşleşmiyor!");
        return;
    }
    
    if (newPass.length < 8) {
        alert("Yeni şifre en az 8 karakter olmalı!");
        return;
    }
    
    try {
        const res = await fetch('/api/change-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ oldPassword: oldPass, newPassword: newPass })
        });
        
        if (res.ok) {
            alert("✅ Şifre başarıyla değiştirildi!");
            
            // Yeni şifreyi kaydet
            const username = localStorage.getItem('admin_username');
            if (username) {
                localStorage.setItem('admin_password', newPass);
            }
            
            // Formu temizle
            if(document.getElementById('old-pass')) {
                document.getElementById('old-pass').value = '';
                document.getElementById('new-pass').value = '';
                document.getElementById('new-pass-confirm').value = '';
            }
            
        } else {
            const error = await res.json();
            alert(`Hata: ${error.error}`);
        }
    } catch (err) {
        console.error("Şifre değiştirme hatası:", err);
        alert("Sunucu hatası oluştu!");
    }
}

// ⭐ YENİ: Sayfa yüklendiğinde
window.onload = function() {
    // Admin sayfasındaysak otomatik giriş dene
    if (window.location.pathname.includes('admin.html')) {
        // İlk kurulum kontrolü
        fetch('/api/check-setup')
            .then(res => res.json())
            .then(data => {
                if (!data.hasAdmin) {
                    // Admin yoksa, kurulum formu göster
                    document.getElementById('login-area').innerHTML = `
                        <div class="card" style="text-align: center; background: #f0f9ff;">
                            <h2>🎯 İlk Kurulum</h2>
                            <p>İlk admin hesabınızı oluşturun:</p>
                            <input type="text" id="setup-user" placeholder="Kullanıcı Adı" value="admin" style="margin: 10px 0;">
                            <input type="password" id="setup-pass" placeholder="Şifre (en az 8 karakter)" style="margin-bottom: 10px;">
                            <input type="password" id="setup-pass-confirm" placeholder="Şifre Tekrar" style="margin-bottom: 20px;">
                            <button onclick="setupAccount()" style="width: 100%; background: #10b981; color: white;">
                                Hesap Oluştur
                            </button>
                        </div>
                    `;
                } else {
                    // Admin varsa otomatik giriş dene
                    autoLogin();
                }
            });
    } else {
        // Ana sayfadaysa verileri yükle
        loadData();
    }
};

// ⭐ YENİ: Kurulum fonksiyonu
async function setupAccount() {
    const username = document.getElementById('setup-user').value;
    const password = document.getElementById('setup-pass').value;
    const confirm = document.getElementById('setup-pass-confirm').value;
    
    if (!username || !password) {
        alert("Lütfen tüm alanları doldurun!");
        return;
    }
    
    if (password !== confirm) {
        alert("Şifreler eşleşmiyor!");
        return;
    }
    
    if (password.length < 8) {
        alert("Şifre en az 8 karakter olmalı!");
        return;
    }
    
    try {
        const res = await fetch('/api/setup', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ username, password })
        });
        
        if (res.ok) {
            alert("✅ Hesap oluşturuldu! Şimdi giriş yapabilirsiniz.");
            // Bilgileri kaydet ve giriş yap
            localStorage.setItem('admin_username', username);
            localStorage.setItem('admin_password', password);
            autoLogin();
        } else {
            const error = await res.json();
            alert("Hata: " + error.error);
        }
    } catch (err) {
        alert("Sunucu hatası: " + err.message);
    }
}

// ⭐ DEĞİŞMEDİ: Paylaşım formu takibi
document.addEventListener('DOMContentLoaded', () => {
    const postForm = document.getElementById('postForm');
    if (postForm) {
        postForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(postForm);
            
            try {
                const res = await fetch('/api/posts', {
                    method: 'POST',
                    body: formData 
                });

                if (res.ok) {
                    alert("Paylaşım başarıyla yapıldı!");
                    postForm.reset();
                    loadData();
                } else {
                    alert("Paylaşım yapılamadı.");
                }
            } catch (err) {
                console.error("Hata:", err);
            }
        });
    }
});

// ⭐ YENİ: Beğeni işlemini yönet
async function handleLike(postId) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    // Giriş kontrolü
    if (!currentUser.id) {
        if (confirm('Beğeni yapmak için giriş yapmalısınız! Giriş sayfasına yönlendirilsin mi?')) {
            window.location.href = 'login.html';
        }
        return;
    }
    
    const button = document.querySelector(`.like-btn[data-post-id="${postId}"]`);
    if (!button) return;
    
    try {
        // Butonu devre dışı bırak
        button.disabled = true;
        const originalHTML = button.innerHTML;
        
        // API'yi çağır
        const res = await fetch(`/api/posts/${postId}/like`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const data = await res.json();
        
        if (data.success) {
            // Beğeni sayısını güncelle
            const likeCountSpan = button.querySelector('.like-count');
            let currentCount = parseInt(likeCountSpan.textContent) || 0;
            
            if (data.liked) {
                // Beğeni eklendi
                button.innerHTML = '❤️ <span class="like-count">' + (currentCount + 1) + '</span>';
                button.style.background = '#dc2626';
                button.style.color = 'white';
                button.classList.add('liked');
                showLikeMessage('❤️ Beğendiniz!');
            } else {
                // Beğeni kaldırıldı
                button.innerHTML = '🤍 <span class="like-count">' + (currentCount - 1) + '</span>';
                button.style.background = '#f3f4f6';
                button.style.color = '#374151';
                button.classList.remove('liked');
                showLikeMessage('💔 Beğeni kaldırıldı');
            }
            
        } else {
            alert('Beğeni işlemi başarısız: ' + (data.error || 'Bilinmeyen hata'));
        }
        
    } catch (err) {
        console.error('Beğeni hatası:', err);
        alert('Sunucu hatası!');
    } finally {
        button.disabled = false;
    }
}

// ⭐ YENİ: Beğeni mesajı göster
function showLikeMessage(text) {
    // Var olan mesajı temizle
    const oldMsg = document.getElementById('like-message');
    if (oldMsg) oldMsg.remove();
    
    // Yeni mesaj oluştur
    const msg = document.createElement('div');
    msg.id = 'like-message';
    msg.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: linear-gradient(135deg, #3b82f6, #8b5cf6);
        color: white;
        padding: 12px 20px;
        border-radius: 10px;
        font-weight: bold;
        z-index: 9999;
        animation: slideIn 0.3s ease-out;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    `;
    msg.textContent = text;
    
    document.body.appendChild(msg);
    
    // 2 saniye sonra kaldır
    setTimeout(() => {
        msg.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => msg.remove(), 300);
    }, 2000);
}

// ==================== DOSYA GÖRÜNTÜLEME SİSTEMİ ====================

// Dosya önizleme için global değişken
let currentPreviewFile = null;

// Dosya ikonunu belirle
function getFileIcon(file) {
    const type = file.type || '';
    const name = file.name ? file.name.toLowerCase() : '';
    
    if (type.startsWith('image/')) return '🖼️';
    if (type.startsWith('video/')) return '🎥';
    if (type.startsWith('audio/')) return '🎵';
    if (type === 'application/pdf') return '📄';
    if (type === 'application/zip' || type === 'application/x-rar-compressed') return '📦';
    if (name.endsWith('.html') || name.endsWith('.htm')) return '🌐';
    if (name.endsWith('.css')) return '🎨';
    if (name.endsWith('.js')) return '⚡';
    if (name.endsWith('.json')) return '📋';
    if (name.endsWith('.txt')) return '📝';
    if (name.includes('.')) return '📎';
    
    return '📁';
}

// Dosya boyutunu formatla
function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 Byte';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Dosya eklerini render et
function renderFileAttachments(files) {
    if (!files || files.length === 0) return '';
    
    return files.map(file => {
        const icon = getFileIcon(file);
        const size = formatFileSize(file.size || 0);
        const type = getFileTypeText(file.type);
        
        return `
            <div class="file-attachment" onclick="previewFile(${JSON.stringify(file).replace(/"/g, '&quot;')})">
                <div class="file-icon-lg">${icon}</div>
                <div class="file-details">
                    <div class="file-title" title="${file.name}">${file.name}</div>
                    <div class="file-meta">
                        <span>${type}</span>
                        <span>•</span>
                        <span>${size}</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function getFileTypeText(type) {
    if (!type) return 'Dosya';
    if (type.startsWith('image/')) return 'Resim';
    if (type.startsWith('video/')) return 'Video';
    if (type.startsWith('audio/')) return 'Ses';
    if (type === 'application/pdf') return 'PDF';
    if (type === 'application/zip') return 'ZIP';
    if (type === 'application/x-rar-compressed') return 'RAR';
    if (type.startsWith('text/')) return 'Metin';
    if (type.includes('javascript')) return 'JavaScript';
    return 'Dosya';
}

// ==================== DOSYA ÖNİZLEME ====================

function previewFile(file) {
    currentPreviewFile = file;
    
    const modal = document.getElementById('filePreviewModal');
    if (!modal) {
        createFilePreviewModal();
    }
    
    const previewModal = document.getElementById('filePreviewModal');
    const previewBody = document.getElementById('previewBody');
    const previewHeader = document.getElementById('previewFileName');
    const downloadBtn = document.getElementById('downloadBtn');
    
    previewHeader.textContent = file.name;
    downloadBtn.onclick = () => downloadFile(file);
    
    // Dosya türüne göre içerik göster
    previewBody.innerHTML = renderFilePreview(file);
    
    previewModal.style.display = 'flex';
}

function createFilePreviewModal() {
    const modal = document.createElement('div');
    modal.id = 'filePreviewModal';
    modal.className = 'file-preview-modal';
    modal.innerHTML = `
        <div class="preview-content">
            <div class="preview-header">
                <span id="previewFileName"></span>
                <button class="preview-close" onclick="closeFilePreview()">×</button>
            </div>
            <div class="preview-body" id="previewBody"></div>
            <div class="preview-actions">
                <button class="download-btn" id="downloadBtn">
                    ⬇️ İndir
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Modal dışına tıklandığında kapat
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            closeFilePreview();
        }
    });
}

function renderFilePreview(file) {
    const type = file.type || '';
    const url = file.url || '';
    const name = file.name || '';
    
    // Resim dosyası
    if (type.startsWith('image/')) {
        return `<img src="${url}" class="preview-file" alt="${name}">`;
    }
    
    // Video dosyası
    if (type.startsWith('video/')) {
        return `
            <video controls class="preview-file">
                <source src="${url}" type="${type}">
                Tarayıcınız video etiketini desteklemiyor.
            </video>
        `;
    }
    
    // Ses dosyası
    if (type.startsWith('audio/')) {
        return `
            <audio controls class="preview-file" style="width: 100%;">
                <source src="${url}" type="${type}">
                Tarayıcınız ses etiketini desteklemiyor.
            </audio>
        `;
    }
    
    // PDF dosyası
    if (type === 'application/pdf') {
        return `
            <iframe src="${url}" class="preview-file" style="width: 100%; height: 500px;"></iframe>
            <p style="text-align: center; margin-top: 10px;">
                <a href="${url}" target="_blank" style="color: var(--primary);">PDF'yi yeni sekmede aç</a>
            </p>
        `;
    }
    
    // Metin dosyaları
    if (type.startsWith('text/') || 
        name.endsWith('.js') || 
        name.endsWith('.css') || 
        name.endsWith('.html') || 
        name.endsWith('.txt') || 
        name.endsWith('.json')) {
        
        return `
            <div style="text-align: center; margin-bottom: 15px;">
                <button onclick="loadTextFile('${url}', '${name}')" class="download-btn">
                    📄 Dosya İçeriğini Göster
                </button>
            </div>
            <div id="textPreview" class="code-viewer">
                Dosya yükleniyor...
            </div>
        `;
    }
    
    // Diğer dosyalar
    return `
        <div style="text-align: center; padding: 40px;">
            <div style="font-size: 4rem; margin-bottom: 20px;">${getFileIcon(file)}</div>
            <h3>${name}</h3>
            <p>Bu dosya türü tarayıcıda önizlenemiyor.</p>
            <p style="color: var(--secondary);">Tür: ${type || 'Bilinmiyor'}</p>
            <p style="color: var(--secondary);">Boyut: ${formatFileSize(file.size || 0)}</p>
        </div>
    `;
}

async function loadTextFile(url, filename) {
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error('Dosya yüklenemedi');
        
        const text = await response.text();
        const textPreview = document.getElementById('textPreview');
        
        const lines = text.split('\n');
        textPreview.innerHTML = lines.map((line, index) => `
            <div class="code-line">
                <span class="code-line-number">${index + 1}</span>
                <span>${escapeHtml(line)}</span>
            </div>
        `).join('');
        
    } catch (err) {
        document.getElementById('textPreview').innerHTML = 
            '<div style="color: #dc2626; text-align: center; padding: 20px;">❌ Dosya yüklenemedi</div>';
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function downloadFile(file) {
    if (!file || !file.url) {
        showNotification('❌ Dosya indirilemedi', 'error');
        return;
    }
    
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name || 'dosya';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification(`✅ "${file.name}" indiriliyor...`, 'success');
}

function closeFilePreview() {
    const modal = document.getElementById('filePreviewModal');
    if (modal) {
        modal.style.display = 'none';
    }
    currentPreviewFile = null;
}

function previewImage(url, title = 'Resim') {
    const file = {
        url: url,
        name: title,
        type: 'image/jpeg'
    };
    previewFile(file);
}

// ==================== DİĞER FONKSİYONLAR ====================

function toggleFiles(element) {
    const filesList = element.nextElementSibling;
    const arrow = element.querySelector('span:last-child');
    
    if (filesList.classList.contains('open')) {
        filesList.classList.remove('open');
        arrow.textContent = '▼';
    } else {
        filesList.classList.add('open');
        arrow.textContent = '▲';
    }
}

// Global fonksiyonları tanımla
window.previewFile = previewFile;
window.closeFilePreview = closeFilePreview;
window.previewImage = previewImage;
window.downloadFile = downloadFile;
window.loadTextFile = loadTextFile;
window.toggleFiles = toggleFiles;

console.log('✅ Dosya görüntüleme sistemi yüklendi');